const userSchools = {
    "schools": [
        {
            "type": "Bachelor's Degree",
            "name": "Dummy University",
            "address": {
                "street": "123 Dummy University Street",
                "city": "Dummyville",
                "state": "Dummystate",
                "zip": "Dummy ZIP"
            },
            "major": "Dummy Major",
            "minor": "Dummy Minor (delete field if none)",
            "gpa": 0.0,
            "graduation": "(Grad Month and Year)",
            "clubs": [
                {
                    "name": "Dummy Club",
                    "position": "Dummy Position"
                },
            ]
        },
        {
            "type": "High School",
            "name": "Dummy High School",
            "address": {
                "street": "321 Dummy High School Street",
                "city": "Dummyville",
                "state": "Dummystate",
                "zip": "Dummy ZIP"
            },
            "major": "General Studies",
            "gpa": 0.0,
            "graduation": "(Grad Month and Year)"
        }
    ]
}