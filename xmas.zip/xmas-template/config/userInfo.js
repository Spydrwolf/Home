const userInfo = {
    "image": "./image.png",
    "headerFont": "Comic Sans MS",
    "name": {
        "first": "Dummy",
        "last": "User"
    },
    "about": {
        "title": "Dummy Title",
        "description": "Dummy Bio goes here.",
        "social": [
            {
                "name": "example-social-network",
                "url": "http://example.com/social",
                "icon": {
                    "set": "fas",
                    "iconName": "fa-info"
                }
            },
        ]
    }
}