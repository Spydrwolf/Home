const userSkills = {
    "skills": [
        {
            "name": "Dummy skill with icon and/or link",
            "icon": "fas fa-info",
            "link": "https://example.com"
        },
        "Dummy Skill or Attribute with no icon or link",
        "Another Dummy skill with no icon or link",
    ]
}