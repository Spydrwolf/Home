const userJobs = {
    "jobs": [
        {
            "company": "Dummy Company",
            "title": "Dummy Job Title",
            "description": "Dummy job description",
            "start": "(Job start date here)",
            "end": "(Job end date here)"
        },
    ]
}