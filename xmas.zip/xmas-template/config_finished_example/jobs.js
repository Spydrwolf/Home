const userJobs = {
    "jobs": [
        {
            "company": "Dakota State University",
            "title": "Social Media Specialist (WS)",
            "description": "I am responsible for creating social media content for the university.",
            "start": "8-17-2022",
            "end": "Present"
        },
        {
            "company": "The Globe Chophouse (EmmeLu B's LLC)",
            "title": "Line Cook/Dishwasher/Food Photographer/Web Developer",
            "description": "I was responsible for a large amount of internal processes for the business over the course of my employment. I was also responsible for creating the website for the business, a project which was later scrapped upon my departure.",
            "start": "5-26-2021",
            "end": "8-1-2022"
        }
    ]
}