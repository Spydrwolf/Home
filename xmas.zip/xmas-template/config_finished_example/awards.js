const userAwards ={
    "certifications": [
        {
            "name": "DSU Rising Scholar",
            "date": "2022"
        },
        {
            "name": "DSU Elite Champion Scholar",
            "date": "2022"
        }
    ],
}